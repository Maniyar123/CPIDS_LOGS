sap.ui.define([
    "sap/m/MessageToast"
], function (MessageToast) {
    'use strict';
    var that;
    return {

        onInit: function () {
            that=this;
            that.byId("vcpif.salesconfig::sap.suite.ui.generic.template.ListReport.view.ListReport::SALESH_CONFIG_STB--addEntry").setVisible(false); // Replace with the actual ID
            // if (oButton) {
            //     oButton.setVisible(true);
            // }
        },
        

        // ---------create frgamnet loading--------
        onPressCreate: function (oEvent) {
            that = this;
            // var oView = that.getView();
            // Check if the dialog already exists
            if (!this._oCreateFragment) {
                this._oCreateFragment = sap.ui.xmlfragment("vcpif.salesconfig.fragments.createFragment", this);
                // oView.addDependent(this._oCharacteristicCreateFragment);
            }

            // Open the dialog
            this._oCreateFragment.open();


        },
        //  ----------save functionality inside create button-------------
        // onSaveSaleshConfig: function () {
        //     var that = this;

        //     // Get current date and time
        //     var currentDate = new Date();
        //     var createdDate = currentDate.toISOString().split('T')[0];  // Date format yyyy-MM-dd
        //     var createdTime = currentDate.toTimeString().split(' ')[0];  // Time format HH:mm:ss
        //     var changedDate = null  // Same as created date for new records
        //     var changedTime = null  // Same as created time for new records

        //     // Default user if sap.ushell is not available
        //     var currentUser = "Unknown User";

        //     // Check if sap.ushell.Container is available (for BTP environment)
        //     if (typeof window.sap !== "undefined" && window.sap.ushell && window.sap.ushell.Container) {
        //         try {
        //             var oUserInfoService = sap.ushell.Container.getService("UserInfo");
        //             currentUser = oUserInfoService.getUser().getFullName(); // Fetch the full name of the user
        //         } catch (e) {
        //             console.error("Error retrieving user info:", e);
        //             currentUser = "Error Retrieving User"; // Fallback in case of any error
        //         }
        //     } else {
        //         console.log("sap.ushell.Container is not available. Using fallback user.");
        //     }

        //     // Collect form data from the fragment
        //     var prodAvailabilityDate = sap.ui.getCore().byId("prodAvailabilityDateInput").getDateValue();
        //     var formattedProdAvailabilityDate = prodAvailabilityDate
        //         ? prodAvailabilityDate.toISOString().split('T')[0] // Convert to YYYY-MM-DD
        //         : null; // Handle null case if date is not provided

        //     var oData = {
        //         MANDT: sap.ui.getCore().byId("mandtInput").getValue(),
        //         SALES_DOCUMENT: sap.ui.getCore().byId("salesDocumentInput").getValue(),
        //         SALES_DOCUMENT_ITEM: sap.ui.getCore().byId("salesDocumentItemInput").getValue(),
        //         CHARACTERSTIC: sap.ui.getCore().byId("characteristicInput").getValue(),
        //         CHARACTERSTIC_VALUE: sap.ui.getCore().byId("characteristicValueInput").getValue(),
        //         PRODUCT_ID: sap.ui.getCore().byId("productIdInput").getValue(),
        //         PROD_AVAILABILITY_DT: formattedProdAvailabilityDate, // Properly formatted date
        //         CLASS: sap.ui.getCore().byId("classInput").getValue(),
        //         CLASS_NUM: sap.ui.getCore().byId("classNumInput").getValue(),
        //         CHARACTERSTIC_NUM: sap.ui.getCore().byId("charNumInput").getValue(),
        //         VALUE_NUM: sap.ui.getCore().byId("valueNumInput").getValue(),
        //         DELETE_FLAG: sap.ui.getCore().byId("deleteFlagInput").getValue(),
        //         CHANGED_DATE: changedDate,
        //         CHANGED_TIME: changedTime,
        //         CHANGED_BY: "", // Set current user as CHANGED_BY
        //         CREATED_DATE: createdDate,
        //         CREATED_TIME: createdTime,
        //         CREATED_BY: currentUser // Set current user as CREATED_BY
        //     };

        //     // Validate required fields
        //     // if (!oData.SALES_DOCUMENT_ITEM) {
        //     //     MessageToast.show("SALES_DOCUMENT_ITEM is required.");
        //     //     return;
        //     // }

        //     // Get the OData model
        //     var oModel = that.getView().getModel();

        //     // Check if the LOCATION_ID already exists
        //     // If LOCATION_ID does not exist, proceed to create
        //     oModel.create("/SALESH_CONFIG_STB", oData, {
        //         success: function () {
        //             MessageToast.show("Location created successfully.");
        //             oModel.refresh();
        //             // Close the dialog after successful save
        //             if (that._oCreateFragment) {
        //                 that._oCreateFragment.close();
        //                 that._oCreateFragment.destroy();
        //                 that._oCreateFragment = null;
        //             }
        //         },
        //         error: function () {
        //             MessageToast.show("Failed to create location.");
        //         }
        //     });
        // },
        onSaveSaleshConfig: function () {
            var that = this;
        
            // Get current date and time
            var currentDate = new Date();
            var createdDate = currentDate.toISOString().split('T')[0]; // Date format yyyy-MM-dd
            var createdTime = currentDate.toTimeString().split(' ')[0]; // Time format HH:mm:ss
            var changedDate = null; // Same as created date for new records
            var changedTime = null; // Same as created time for new records
        
            // Default user if sap.ushell is not available
            var currentUser = "Unknown User";
        
            // Check if sap.ushell.Container is available (for BTP environment)
            if (typeof window.sap !== "undefined" && window.sap.ushell && window.sap.ushell.Container) {
                try {
                    var oUserInfoService = sap.ushell.Container.getService("UserInfo");
                    currentUser = oUserInfoService.getUser().getFullName(); // Fetch the full name of the user
                } catch (e) {
                    console.error("Error retrieving user info:", e);
                    currentUser = "Error Retrieving User"; // Fallback in case of any error
                }
            } else {
                console.log("sap.ushell.Container is not available. Using fallback user.");
            }
        
            // Collect form data from the fragment
            var prodAvailabilityDate = sap.ui.getCore().byId("prodAvailabilityDateInput").getDateValue();
            var formattedProdAvailabilityDate = prodAvailabilityDate
                ? prodAvailabilityDate.toISOString().split('T')[0] // Convert to YYYY-MM-DD
                : null; // Handle null case if date is not provided
        
            var oData = {
                MANDT: sap.ui.getCore().byId("mandtInput").getValue(),
                SALES_DOCUMENT: sap.ui.getCore().byId("salesDocumentInput").getValue(),
                SALES_DOCUMENT_ITEM: sap.ui.getCore().byId("salesDocumentItemInput").getValue(),
                CHARACTERSTIC: sap.ui.getCore().byId("characteristicInput").getValue(),
                CHARACTERSTIC_VALUE: sap.ui.getCore().byId("characteristicValueInput").getValue(),
                PRODUCT_ID: sap.ui.getCore().byId("productIdInput").getValue(),
                PROD_AVAILABILITY_DT: formattedProdAvailabilityDate, // Properly formatted date
                CLASS: sap.ui.getCore().byId("classInput").getValue(),
                CLASS_NUM: sap.ui.getCore().byId("classNumInput").getValue(),
                CHARACTERSTIC_NUM: sap.ui.getCore().byId("charNumInput").getValue(),
                VALUE_NUM: sap.ui.getCore().byId("valueNumInput").getValue(),
                DELETE_FLAG: sap.ui.getCore().byId("deleteFlagInput").getValue(),
                CHANGED_DATE: changedDate,
                CHANGED_TIME: changedTime,
                CHANGED_BY: "", // Set current user as CHANGED_BY
                CREATED_DATE: createdDate,
                CREATED_TIME: createdTime,
                CREATED_BY: currentUser // Set current user as CREATED_BY
            };
        
            // Validate required fields
            if (!oData.SALES_DOCUMENT || !oData.SALES_DOCUMENT_ITEM || !oData.MANDT ||!oData.CHARACTERSTIC ||!oData.CHARACTERSTIC_VALUE) {
                sap.m.MessageToast.show(" above fields are required.");
                return;
            }
        
            // Get the OData model
            var oModel = that.getView().getModel();
        
            // Fetch existing records and check if the data already exists
            oModel.read("/SALESH_CONFIG_STB", {
                success: function (oDataResponse) {
                    console.log("Fetched Data:", oDataResponse.results); // Debug fetched data
            
                    // Check for existing record
                    var exists = oDataResponse.results.some(function (record) {
                        return (
                            String(record.SALES_DOCUMENT).trim() === String(oData.SALES_DOCUMENT).trim() &&
                            String(record.SALES_DOCUMENT_ITEM).trim() === String(oData.SALES_DOCUMENT_ITEM).trim()
                        );
                    });
                    
                    if (exists) {
                        sap.m.MessageToast.show("Record with SALES_DOCUMENT and SALES_DOCUMENT_ITEM already exists.");
                        return;
                    }
                    
            
                    // Proceed to create if no existing record found
                    oModel.create("/SALESH_CONFIG_STB", oData, {
                        success: function () {
                            sap.m.MessageToast.show("Location created successfully.");
                            oModel.refresh();
            
                            // Close the dialog after successful save
                            if (that._oCreateFragment) {
                                that._oCreateFragment.close();
                                that._oCreateFragment.destroy();
                                that._oCreateFragment = null;
                            }
                        },
                        error: function () {
                            sap.m.MessageToast.show("Failed to create.");
                        }
                    });
                },
                error: function () {
                    sap.m.MessageToast.show("Error checking for existing record.");
                }
            });
            
        },
        
        // -----create frgamnet cancel button-----------
        onCancelSaleshConfig: function () {
            if (that._oCreateFragment) {
                that._oCreateFragment.close();
                that._oCreateFragment.destroy();
                that._oCreateFragment = null;
            }
        },
        // ---------numaric value validation ---------------
        onNumericInput: function (oEvent) {
            var oInput = oEvent.getSource();
            var sValue = oInput.getValue();

            // Replace non-numeric characters
            var sNumericValue = sValue.replace(/\D/g, '');

            // Update the input field with the numeric value
            oInput.setValue(sNumericValue);
        },



        // ------------downalod templete funtionality---------------------
        onDownTemp: function (oEvent) {
            var oModel = this.getView().getModel(); // Ensure the model is bound to view
            var sMetadataUrl = oModel.sServiceUrl + "/$metadata"; // Fetch metadata URL from the model

            // Fetch metadata XML
            fetch(sMetadataUrl)
                .then(response => response.text())
                .then(metadataXML => {
                    // Parse the metadata XML
                    var parser = new DOMParser();
                    var oMetadataDoc = parser.parseFromString(metadataXML, "application/xml");

                    // Extract entity type 
                    var oEntityType = oMetadataDoc.querySelector("EntityType[Name='SALESH_CONFIG_STB']");

                    if (!oEntityType) {
                        MessageToast.show("Entity type 'LOCATION_STB' not found.");
                        return;
                    }

                    // Define the properties to exclude
                    var aExcludedFields = [
                        "CHANGED_DATE",
                        "CHANGED_TIME",
                        "CHANGED_BY",
                        "CREATED_DATE",
                        "CREATED_TIME",
                        "CREATED_BY"
                    ];

                    // Extract the column headings (properties of the entity type)
                    var oProperties = oEntityType.querySelectorAll("Property");
                    var aColumns = [];

                    oProperties.forEach(function (oProperty) {
                        var sPropertyName = oProperty.getAttribute("Name");
                        if (!aExcludedFields.includes(sPropertyName)) {
                            aColumns.push(sPropertyName);
                        }
                    });

                    if (aColumns.length === 0) {
                        MessageToast.show("No properties found for the entity after filtering.");
                        return;
                    }

                    // Use XLSX.js to create an Excel file with just headers
                    var wb = XLSX.utils.book_new();  // Create a new workbook
                    var ws = XLSX.utils.aoa_to_sheet([aColumns]);  // Convert the headers to a sheet

                    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");  // Append the sheet to the workbook

                    // Write the workbook to a binary Excel file (XLSX)
                    var wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });

                    // Create a Blob for the Excel file
                    var oBlob = new Blob([wbout], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });

                    // Create a temporary link element
                    var oLink = document.createElement("a");
                    oLink.href = URL.createObjectURL(oBlob);
                    oLink.download = "DownloadTemplate.xlsx"; // Specify the file name

                    // Trigger the download
                    document.body.appendChild(oLink);
                    oLink.click();
                    document.body.removeChild(oLink);

                    MessageToast.show("Template downloaded successfully.");
                })
                .catch(function (oError) {
                    MessageToast.show("Error loading metadata.");
                    console.error(oError);
                });

        },




        // --------update button frgamnet loading---------
        // onUpdate: function (oEvent) {
        //     var that = this;

        //     // Try to find the table dynamically
        //     var oTable = sap.ui.getCore().byId("vcpif.salesconfig::sap.suite.ui.generic.template.ListReport.view.ListReport::SALESH_CONFIG_STB--responsiveTable");

        //     // Check if oTable is available
        //     if (!oTable) {
        //         sap.m.MessageToast.show("Table not found!");
        //         return;
        //     }

        //     // Get selected items from the table
        //     var aSelectedItems = oTable.getSelectedContexts();

        //     // Check if no record is selected
        //     if (aSelectedItems.length === 0) {
        //         sap.m.MessageToast.show("Please select a record to update.");
        //         return;
        //     }

        //     // Check if more than one record is selected
        //     if (aSelectedItems.length > 1) {
        //         sap.m.MessageToast.show("Please select only one record to update.");
        //         return;
        //     }

        //     // Get the selected location data from the context
        //     var oSelectedContext = aSelectedItems[0];
        //     var oSelectedItem = oSelectedContext.getObject();
        //     var sSelectedId = oSelectedItem.MANDT; // Extract the ID of the selected record

        //     // Get the OData model
        //     var oModel = this.getView().getModel(); // Assuming this is the correct OData model

        //     // Read the entire dataset (use caution with large datasets)
        //     oModel.read("/SALESH_CONFIG_STB", {
        //         success: function (oData) {
        //             // Filter the results using ===
        //             var aResults = oData.results || [];
        //             var oFilteredData = aResults.find(function (item) {
        //                 return item.MANDT === sSelectedId;
        //             });

        //             // Create a JSON model and set the fetched data
        //             var oJSONModel = new sap.ui.model.json.JSONModel(oFilteredData);

        //             // Set the model globally or to the view
        //             sap.ui.getCore().setModel(oJSONModel, "selectedSalesModel");

        //             // Check if the dialog is already created
        //             if (!that._oSalesConfigUpdateDialog) {
        //                 // Create the dialog only once
        //                 that._oSalesConfigUpdateDialog = sap.ui.xmlfragment("vcpif.salesconfig.fragments.updateFragment", that);

        //                 // Add the dialog as a dependent of the view (optional, if needed)
        //                 that.getView().addDependent(that._oSalesConfigUpdateDialog);
        //             }

        //             // Set the dialog's model
        //             that._oSalesConfigUpdateDialog.setModel(oJSONModel, "selectedSalesModel");

        //             // Open the dialog
        //             that._oSalesConfigUpdateDialog.open();
        //         },
        //         error: function (oError) {
        //             sap.m.MessageToast.show("Error fetching location data.");
        //         }
        //     });
        // },
        onUpdate: function (oEvent) {
            var that = this;
        
            // Try to find the table dynamically
            var oTable = sap.ui.getCore().byId("vcpif.salesconfig::sap.suite.ui.generic.template.ListReport.view.ListReport::SALESH_CONFIG_STB--responsiveTable");
        
            // Check if oTable is available
            if (!oTable) {
                sap.m.MessageToast.show("Table not found!");
                return;
            }
        
            // Get selected items from the table
            var aSelectedItems = oTable.getSelectedContexts();
        
            // Check if no record is selected
            if (aSelectedItems.length === 0) {
                sap.m.MessageToast.show("Please select a record to update.");
                return;
            }
        
            // Check if more than one record is selected
            if (aSelectedItems.length > 1) {
                sap.m.MessageToast.show("Please select only one record to update.");
                return;
            }
        
            // Get the selected location data from the context
            var oSelectedContext = aSelectedItems[0];
            var oSelectedItem = oSelectedContext.getObject();
        
            // Extract the necessary key fields (excluding MANDT)
            var sSalesDocument = oSelectedItem.SALES_DOCUMENT;
            var iSalesDocumentItem = oSelectedItem.SALES_DOCUMENT_ITEM;
            var sCharacteristic = oSelectedItem.CHARACTERSTIC;
            var sCharacteristicValue = oSelectedItem.CHARACTERSTIC_VALUE;
        
            // Get the OData model
            var oModel = this.getView().getModel();
        
            // Read the entire dataset (use caution with large datasets)
            oModel.read("/SALESH_CONFIG_STB", {
                success: function (oData) {
                    var aResults = oData.results || [];
                    
                    // Filter the results using the key fields (excluding MANDT)
                    var oFilteredData = aResults.find(function (item) {
                        return item.SALES_DOCUMENT === sSalesDocument &&
                               item.SALES_DOCUMENT_ITEM === iSalesDocumentItem &&
                               item.CHARACTERSTIC === sCharacteristic &&
                               item.CHARACTERSTIC_VALUE === sCharacteristicValue;
                    });
        
                    // Debugging step: Check if the filtered data exists and inspect the PROD_AVAILABILITY_DT value
                    console.log("Filtered Data:", oFilteredData);
        
                    if (!oFilteredData) {
                        sap.m.MessageToast.show("No matching data found.");
                        return;
                    }
        
                    // Debugging step: Check if PROD_AVAILABILITY_DT is present in the data
                    console.log("PROD_AVAILABILITY_DT:", oFilteredData.PROD_AVAILABILITY_DT);
        
                    // If PROD_AVAILABILITY_DT is not null or undefined, format the date
                    if (oFilteredData.PROD_AVAILABILITY_DT) {
                        var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
                            pattern: "dd/MM/yyyy"
                        });
                        var sFormattedDate = oDateFormat.format(oFilteredData.PROD_AVAILABILITY_DT);
        
                        // Update the PROD_AVAILABILITY_DT with the formatted date
                        oFilteredData.PROD_AVAILABILITY_DT = sFormattedDate;
                    }
        
                    // Create a JSON model and set the fetched data
                    var oJSONModel = new sap.ui.model.json.JSONModel(oFilteredData);
        
                    // Check if the dialog is already created
                    if (!that._oSalesConfigUpdateDialog) {
                        // Create the dialog only once
                        that._oSalesConfigUpdateDialog = sap.ui.xmlfragment("vcpif.salesconfig.fragments.updateFragment", that);
                        that.getView().addDependent(that._oSalesConfigUpdateDialog);
                    }
        
                    // Ensure the model is set to the dialog and the context is updated
                    that._oSalesConfigUpdateDialog.setModel(oJSONModel, "selectedSalesModel");
                    that._oSalesConfigUpdateDialog.setBindingContext(oSelectedContext); // Ensure correct binding context
        
                    // Open the dialog
                    that._oSalesConfigUpdateDialog.open();
                },
                error: function (oError) {
                    sap.m.MessageToast.show("Error fetching location data.");
                }
            });
        },
        
        
        
        
        

        // -------update buton inside frgamnet----------
        onUpdateSalesConfig: function () {
            var that = this;
            // Default user if sap.ushell is not available
            var currentUser = "Unknown User";

            // Check if sap.ushell.Container is available (for BTP environment)
            if (typeof window.sap !== "undefined" && window.sap.ushell && window.sap.ushell.Container) {
                try {
                    var oUserInfoService = sap.ushell.Container.getService("UserInfo");
                    currentUser = oUserInfoService.getUser().getFullName(); // Fetch the full name of the user
                } catch (e) {
                    console.error("Error retrieving user info:", e);
                    currentUser = "Error Retrieving User"; // Fallback in case of any error
                }
            } else {
                console.log("sap.ushell.Container is not available. Using fallback user.");
            }
            // Collect form data from the fragment
            var oData = {
                MANDT: sap.ui.getCore().byId("mandtUpdateInput").getValue(), // Include MANDT in the data payload
                SALES_DOCUMENT: sap.ui.getCore().byId("salesDocumentUpdateInput").getValue(),
                SALES_DOCUMENT_ITEM: sap.ui.getCore().byId("salesDocumentItemUpdateInput").getValue(),
                CHARACTERSTIC: sap.ui.getCore().byId("characteristicUpdateInput").getValue(),
                CHARACTERSTIC_VALUE: sap.ui.getCore().byId("characteristicValueUpdateInput").getValue(),
                PRODUCT_ID: sap.ui.getCore().byId("productIdUpdateInput").getValue(),
                PROD_AVAILABILITY_DT: sap.ui.getCore().byId("prodAvailabilityDateUpdateInput").getDateValue(),
                CLASS: sap.ui.getCore().byId("classUpdateInput").getValue(),
                CLASS_NUM: sap.ui.getCore().byId("classNumUpdateInput").getValue(),
                CHARACTERSTIC_NUM: sap.ui.getCore().byId("charNumUpdateInput").getValue(),
                VALUE_NUM: sap.ui.getCore().byId("valueNumUpdateInput").getValue(),
                DELETE_FLAG: sap.ui.getCore().byId("deleteFlagUpdateInput").getValue(),
                CHANGED_DATE: new Date().toISOString().split('T')[0], // Current date in YYYY-MM-DD format
                CHANGED_TIME: new Date().toTimeString().split(' ')[0], // Current time in HH:mm:ss format
                CHANGED_BY: currentUser // Replace with actual logic to fetch current user
            };

            // Validate required fields
            if (!oData.SALES_DOCUMENT || !oData.SALES_DOCUMENT_ITEM || !oData.CHARACTERSTIC || !oData.CHARACTERSTIC_VALUE) {
                MessageToast.show("Please fill all required fields.");
                return;
            }

            // Get the OData model
            var oModel = this.getView().getModel();

            // Construct the key for the entity (MANDT is not part of the key fields)
            var sKey = "SALES_DOCUMENT='" + oData.SALES_DOCUMENT + "',SALES_DOCUMENT_ITEM=" + oData.SALES_DOCUMENT_ITEM + ",CHARACTERSTIC='" + oData.CHARACTERSTIC + "',CHARACTERSTIC_VALUE='" + oData.CHARACTERSTIC_VALUE + "'";

            // Update the entity record using OData update method
            oModel.update("/SALESH_CONFIG_STB(" + sKey + ")", oData, {
                success: function () {
                    MessageToast.show("Sales configuration updated successfully.");
                    oModel.refresh();
                    // Close the dialog
                    if (that._oSalesConfigUpdateDialog) {
                        that._oSalesConfigUpdateDialog.close();
                        that._oSalesConfigUpdateDialog.destroy();
                        that._oSalesConfigUpdateDialog = null;
                    }

                },
                error: function () {
                    MessageToast.show("Failed to update sales configuration.");
                }
            });
        },
        // ----cancel button inside update fragmnet-------
        onCancelSalesConfig: function () {
            if (this._oSalesConfigUpdateDialog) {
                this._oSalesConfigUpdateDialog.close();
                this._oSalesConfigUpdateDialog.destroy();
                this._oSalesConfigUpdateDialog = null;
            }
        },

        // ------upload functionality---------
        onPressUpload: function (oEvent) {
            if (!this._fileUploaderFragment) {
                this._fileUploaderFragment = sap.ui.xmlfragment(
                    "vcpif.salesconfig.fragments.uploadFragment", // Path to the fragment
                    this
                );
                // this.getView().addDependent(this._fileUploaderFragment); // Ensure proper lifecycle management
            }
            this._fileUploaderFragment.open();
        },
        onUploadFile: function () {
            var that = this;
            var oFileUploader = sap.ui.getCore().byId("fileUploadDialog");

            if (!oFileUploader) {
                MessageToast.show("File uploader not found.");
                return;
            }

            var oDomRef = oFileUploader.getDomRef();
            if (!oDomRef || !oDomRef.querySelector("input[type='file']")) {
                MessageToast.show("File input not found.");
                return;
            }

            var oFileInput = oDomRef.querySelector("input[type='file']");
            if (!oFileInput.files || oFileInput.files.length === 0) {
                MessageToast.show("No file selected.");
                return;
            }

            var oFile = oFileInput.files[0];
            if (oFile) {
                var oFileReader = new FileReader();

                oFileReader.onload = function (e) {
                    var sData = e.target.result;
                    var workbook = XLSX.read(sData, { type: 'array' });  // Read the file as an array

                    // Extract data from the first sheet (change index if needed)
                    var worksheet = workbook.Sheets[workbook.SheetNames[0]];
                    var jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: "" }); // Parse into an array of rows

                    // Log the parsed data for debugging
                    console.log("Parsed JSON data from the file:", jsonData);

                    // Skip the header row and process the actual data
                    var dataRows = jsonData.slice(1); // Get all rows except the header

                    // If no valid data rows, show a message and exit
                    if (dataRows.length === 0) {
                        MessageToast.show("The file does not contain any valid data.");
                        return;
                    }

                    var uploadedCount = 0;
                    var skippedCount = 0;
                    var skippedRecords = [];

                    // Process each row and prepare the payload for the OData service
                    dataRows.forEach(function (row) {
                        var currentDate = new Date(); // Get the current date and time
                        var currentISODate = currentDate.toISOString().split("T")[0]; // Format as YYYY-MM-DD
                        var currentISOTime = currentDate.toISOString().split("T")[1].split(".")[0]; // Format as HH:MM:SS
                        var changedDate = null  // Same as created date for new records
                        var changedTime = null  // Same as created time for new records

                        // Default user if sap.ushell is not available
                        var currentUser = "Unknown User";

                        // Check if sap.ushell.Container is available (for BTP environment)
                        if (typeof window.sap !== "undefined" && window.sap.ushell && window.sap.ushell.Container) {
                            try {
                                var oUserInfoService = sap.ushell.Container.getService("UserInfo");
                                currentUser = oUserInfoService.getUser().getFullName(); // Fetch the full name of the user
                            } catch (e) {
                                console.error("Error retrieving user info:", e);
                                currentUser = "Error Retrieving User"; // Fallback in case of any error
                            }
                        } else {
                            console.log("sap.ushell.Container is not available. Using fallback user.");
                        }

                        var oFileData = {
                            MANDT: (row[0] || "").toString(),  // Ensure MANDT is a string
                            SALES_DOCUMENT: row[1] || "",  // Adjust field names as per your data
                            SALES_DOCUMENT_ITEM: row[2] || "",  // Default if empty
                            CHARACTERSTIC: row[3] || "",  // Default if empty
                            CHARACTERSTIC_VALUE: row[4] || "",  // Default if empty
                            PRODUCT_ID: row[5] || "",  // Default if empty
                            PROD_AVAILABILITY_DT: row[6] ? new Date(row[6]) : null,  // Handle date field
                            CLASS: row[7] || "",  // Default if empty
                            CLASS_NUM: row[8] || "",  // Default if empty
                            CHARACTERSTIC_NUM: row[9] || "",  // Default if empty
                            VALUE_NUM: row[10] || "",  // Default if empty
                            DELETE_FLAG: row[11] || "",  // Default if empty
                            CREATED_DATE: currentISODate, // Auto-generated date
                            CREATED_TIME: currentISOTime, // Auto-generated time
                            CREATED_BY: currentUser,  // Set current user as CREATED_BY
                            CHANGED_DATE: changedDate, // Auto-generated date
                            CHANGED_TIME: changedTime, // Auto-generated time
                            CHANGED_BY: ""   // Set current user as CHANGED_BY
                        };

                        // Log the data being sent to OData service for debugging
                        console.log("Data to be sent to OData service:", oFileData);

                        // Query the OData service to check if the entity already exists (using an appropriate unique field)
                        var oFilter = new sap.ui.model.Filter("SALES_DOCUMENT", sap.ui.model.FilterOperator.EQ, oFileData.SALES_DOCUMENT);
                        var oModel = that.getView().getModel();

                        oModel.read("/SALESH_CONFIG_STB", {
                            filters: [oFilter],
                            success: function (oData) {
                                // Check if the entity already exists
                                if (oData.results.length === 0) {
                                    // Entity doesn't exist, create a new one
                                    oModel.create("/SALESH_CONFIG_STB", oFileData, {
                                        success: function () {
                                            uploadedCount++;
                                            console.log("Uploaded record:", oFileData.SALES_DOCUMENT);

                                        },
                                        error: function (error) {
                                            // Log the error to debug why the request might be failing
                                            console.error("Error occurred while uploading data:", error);
                                            skippedCount++;
                                            skippedRecords.push(oFileData.SALES_DOCUMENT);
                                        }
                                    });
                                } else {
                                    // Entity already exists, mark as skipped
                                    skippedCount++;
                                    skippedRecords.push(oFileData.SALES_DOCUMENT);
                                }
                            },
                            error: function (error) {
                                console.error("Error occurred while checking for existing entity:", error);
                                skippedCount++;
                                skippedRecords.push(oFileData.SALES_DOCUMENT);
                            }
                        });
                    });

                    // After all records are processed, show appropriate messages
                    setTimeout(function () {
                        if (uploadedCount > 0) {
                            MessageToast.show(uploadedCount + " record(s) uploaded successfully.");
                        }
                        if (skippedCount > 0) {
                            MessageToast.show(skippedCount + " record(s) already exist: " + skippedRecords.join(", "));
                        }
                        if (that._fileUploaderFragment) {
                            that._fileUploaderFragment.close();
                            that._fileUploaderFragment.destroy();
                            that._fileUploaderFragment = null;
                        }
                    }, 2000); // Delay to allow all asynchronous operations to complete
                }.bind(this);

                // Use readAsArrayBuffer instead of readAsBinaryString
                oFileReader.readAsArrayBuffer(oFile);
            }
        },
        onCloseUploadDialog: function () {
            if (this._fileUploaderFragment) {
                this._fileUploaderFragment.close();
                this._fileUploaderFragment.destroy();
                this._fileUploaderFragment = null;
            }
        },

    //    ----------push functionality--------------
        onPush: function (oEvent) {
            const oModel = this.getView().getModel(); // Assuming your OData model is set to the view
            const oTable = this.byId("vcpif.salesconfig::sap.suite.ui.generic.template.ListReport.view.ListReport::SALESH_CONFIG_STB--responsiveTable"); // Replace 'yourTableId' with the actual table ID
            const aSelectedItems = oTable.getSelectedItems(); // Get selected rows
        
            if (aSelectedItems.length === 0) {
                sap.m.MessageToast.show("Please select at least one record.");
                return;
            }
        
            // Build the payload dynamically based on selected records
            const aPayload = aSelectedItems.map((oItem) => {
                const oContext = oItem.getBindingContext(); // Get binding context of the selected row
                const oData = oContext.getObject(); // Get the data object for the row
                return {
                    MANDT: oData.MANDT,
                    SALES_DOCUMENT: oData.SALES_DOCUMENT,
                    SALES_DOCUMENT_ITEM: oData.SALES_DOCUMENT_ITEM,
                    CHARACTERSTIC: oData.CHARACTERSTIC,
                    CHARACTERSTIC_VALUE: oData.CHARACTERSTIC_VALUE,
                    PRODUCT_ID: oData.PRODUCT_ID,
                    PROD_AVAILABILITY_DT: oData.PROD_AVAILABILITY_DT,
                    CLASS: oData.CLASS,
                    CLASS_NUM: oData.CLASS_NUM,
                    CHARACTERSTIC_NUM: oData.CHARACTERSTIC_NUM,
                    VALUE_NUM: oData.VALUE_NUM,
                    DELETE_FLAG: oData.DELETE_FLAG,
                    // CHANGED_DATE: oData.CHANGED_DATE,
                    // CHANGED_TIME: oData.CHANGED_TIME,
                    CHANGED_BY: oData.CHANGED_BY,
                    // CREATED_DATE: oData.CREATED_DATE,
                    // CREATED_TIME: oData.CREATED_TIME,
                    CREATED_BY: oData.CREATED_BY,
                };
            });
        
            // Convert payload to JSON string
            const sPayload = JSON.stringify(aPayload);
            const sEntityN = "SALESH_CONFIG_STB"; // Replace with your entity name
        
            // Call the function
            oModel.callFunction("/pushToVCP", {
                method: "GET", // or "GET" depending on your backend implementation
                urlParameters: {
                    EntityN: sEntityN,
                    payload: sPayload,
                },
                success: (oData) => {
                    sap.m.MessageToast.show(`Success: ${JSON.stringify(oData)}`);
                },
                error: (oError) => {
                    sap.m.MessageToast.show(`Error: ${oError.message}`);
                },
            });
        },
        
    };
});