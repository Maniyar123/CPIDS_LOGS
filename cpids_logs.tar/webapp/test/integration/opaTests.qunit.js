/* global QUnit */

sap.ui.require(["com/cpidslogs/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
