sap.ui.define([
	"com/cpids_logs/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
