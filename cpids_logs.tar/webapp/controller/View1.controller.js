sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
  
], (Controller, Filter, FilterOperator, Fragment,JSONModel,MessageToast) => {
    "use strict";
    var that;
    return Controller.extend("com.cpidslogs.controller.View1", {
        // formatter: formatter,
        onInit() {
            that = this;
            var oModel = this.getOwnerComponent().getModel("cpidsmodel");
            this.getView().setModel(oModel);
            
            //    var oViewModel = new sap.ui.model.json.JSONModel({
            //     selectedStatusType: "All",
            //     selectedStartDate: null,
            //     selectedEndDate: null
            // });
            // this.getView().setModel(oViewModel, "viewModel");
        },
        // onInit: function () {
        //     var that = this;
        //     var oModel = this.getOwnerComponent().getModel("cpidsmodel"); // OData model for fetching data
        //     this.getView().setModel(oModel); // Set the OData model to the view
        
            
        
        //     // Read data from the 'interface_logs' entity set
        //     oModel.read("/interface_logs", {
        //         success: function (oData) {
        //             // Check if the data has been fetched
        //             if (oData.results && oData.results.length > 0) {
        //                 // Format the data, including CREATED_TIME
        //                 var formattedData = oData.results.map(function (log) {
        //                     return {
        //                         LOG_ID: log.LOG_ID,
        //                         LOGNAME: log.LOGNAME,
        //                         STATUS_TYPE: log.STATUS_TYPE,
        //                         STATUS_CODE: log.STATUS_CODE,
        //                         CREATED_DATE: that._formatCreatedDate(log.CREATED_DATE),
        //                         CREATED_TIME: that._formatCreatedTime(log.CREATED_TIME), // Format the CREATED_TIME
        //                         MESSAGE: log.MESSAGE
        //                     };
        //                 });
        
        //                 // Set the formatted data to a JSON model
        //                 var oJSONModel = new sap.ui.model.json.JSONModel({ results: formattedData });
        //                 that.getView().setModel(oJSONModel, "logModel"); // Binding to the view
        
        //                 // Optionally, set a flag that the data is loaded
        //                 that._isDataLoaded = true;
        //             }
        //         },
        //         error: function (oError) {
        //             console.error("Error fetching data:", oError);
        //         }
        //     });
        // },
        _formatCreatedTime: function (time) {
            if (time && time.ms) { // Check if `ms` property exists in the time object
                var ms = time.ms; // Get the milliseconds value
        
                // Create a Date object from the milliseconds value
                var date = new Date(ms);
        
                // Extract hours, minutes, and seconds
                var hours = date.getUTCHours().toString().padStart(2, '0');
                var minutes = date.getUTCMinutes().toString().padStart(2, '0');
                var seconds = date.getUTCSeconds().toString().padStart(2, '0');
        
                // Return the formatted time in HH:mm:ss format
                return hours + ":" + minutes + ":" + seconds;
            }
        
            return "Not Available"; // Default message if no time is available
        },
        _formatCreatedDate: function (date) {
            if (date) {
                // Create a DateFormat instance
                var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
                    pattern: "yyyy-MM-dd"  // You can adjust the pattern to the desired format
                });
        
                // Return the formatted date
                return oDateFormat.format(new Date(date)); // Convert the `CREATED_DATE` to a Date object if needed
            }
        
            return "Not Available"; // Default message if no date is available
        },
        
        
        
        

        onLognameSearch: function (oEvent) {
            var sQuery = oEvent.getParameter("newValue");
            var oTable = this.byId("interfaceLogsTable");
            var oBinding = oTable.getBinding("rows");

            var aFilters = [];
            if (sQuery) {
                // Filter by LOGNAME starting with the search query
                aFilters.push(new Filter("LOGNAME", FilterOperator.StartsWith, sQuery));
            }
            oBinding.filter(aFilters);
        },

        onStatusTypeChange: function (oEvent) {
            var sSelectedStatus = oEvent.getParameter("selectedItem").getKey();
            var oTable = this.byId("interfaceLogsTable");
            var oBinding = oTable.getBinding("rows");

            var aFilters = [];
            if (sSelectedStatus !== "All") {
                // Only apply the filter if a specific status is selected
                aFilters.push(new Filter("STATUS_TYPE", FilterOperator.EQ, sSelectedStatus));
            }

            oBinding.filter(aFilters); // Apply the filters

            // Find the selected log (for example, the first log in the filtered list)
            var aFilteredLogs = oBinding.getContexts();
            if (aFilteredLogs.length > 0) {
                var oSelectedData = aFilteredLogs[0].getObject(); // Get the first log item (you can adjust this logic)

                // Create a JSONModel for the selected log details
                var oSelectedModel = new JSONModel(oSelectedData);
                this.getView().setModel(oSelectedModel, "selectedLog");

                // Optionally, show the log details UI
                this.getView().byId("logDetails").setVisible(true);
            }
        },



        onDateRangeChange: function (oEvent) {
            var oTable = this.byId("interfaceLogsTable"); 
            var oBinding = oTable.getBinding("items"); // Corrected binding
        
            if (!oBinding) {
                console.error("Table binding is undefined. Check model assignment.");
                return;
            }
        
            var oDateRange = oEvent.getSource().getDateValue(); // From Date
            var oEndDate = oEvent.getSource().getSecondDateValue(); // To Date
        
            if (!oDateRange || !oEndDate) {
                oBinding.filter([]); // If no date is selected, remove filters
                return;
            }
        
            var sStartDate = oDateRange.toISOString().split("T")[0];
            var sEndDate = oEndDate.toISOString().split("T")[0];
        
            var oFilter = new Filter({
                filters: [
                    new Filter("CREATED_DATE", FilterOperator.GE, sStartDate),
                    new Filter("CREATED_DATE", FilterOperator.LE, sEndDate)
                ],
                and: true
            });
        
            oBinding.filter([oFilter]); // Apply filter
        },
        


        onViewLogPress: function(oEvent) {
            // Get the selected Log ID from the row
            var oSelectedItem = oEvent.getSource().getParent(); // Get the selected row
            var logID = oSelectedItem.getBindingContext().getProperty("LOG_ID"); // Assuming LOG_ID is part of the row data
            
            // Open the fragment and fetch logs for the selected Log ID
            this.getRequestLogs(logID);
        },

        
       
        // getRequestLogs: function(logID) {
        //     var oModel = this.getOwnerComponent().getModel("cpidsmodel"); // Get the OData model
        //     var oParameters = {
        //         method: "GET", // Specify the HTTP method
        //         urlParameters: {
        //             ID: logID // Pass the log ID as a parameter
        //         },
        //         success: function(oData, response) {
        //             // Data has been successfully fetched
        
        //             // Open the Log Fragment dialog if it is not already open
        //             if (!this._oLogDialog) {
        //                 this._oLogDialog = sap.ui.xmlfragment("com.cpidslogs.fragments.reqLogFragmnet", this);
        //                 this.getView().addDependent(this._oLogDialog); // Add the fragment as a dependent to the view
        //             }
                    
        //             // Set the model for the table inside the fragment
        //             var oLogModel = new JSONModel(oData); // Create a new model with the data
        //             this._oLogDialog.setModel(oLogModel); // Bind the model to the fragment
        
        //             // Open the dialog
        //             this._oLogDialog.open();
        //         }.bind(this),
        //         error: function(oError) {
        //             // Handle error
        //             console.log("Error: ", oError);
        //         }
        //     };
        
        //     // Call the OData function
        //     oModel.callFunction("/getRequestLogs", oParameters);
        // },
        
        getRequestLogs: function(logID) {
            var oModel = this.getOwnerComponent().getModel("cpidsmodel");
            var that = this;
        
            var oParameters = {
                method: "GET",
                urlParameters: { ID: logID },
                success: function(oData) {
                    if (!oData || !oData.getRequestLogs || !oData.getRequestLogs.vcRulesList) {
                        MessageToast.show("No data found!");
                        return;
                    }
        
                    var aFlattenedData = [];
                    oData.getRequestLogs.vcRulesList.forEach(function(oItem) {
                        if (oItem.characteristics && oItem.characteristics.length > 0) {
                            oItem.characteristics.forEach(function(oChar) {
                                aFlattenedData.push({
                                    product: oItem.product,
                                    uniqueIDDescription: oItem.uniqueIDDescription,
                                    externalIdentification: oItem.externalIdentification,
                                    validFrom: oItem.validFrom,
                                    validTo: oItem.validTo,
                                    characteristic: oChar.characteristic,
                                    characteristicValue: oChar.characteristicValue
                                });
                            });
                        } else {
                            aFlattenedData.push({
                                product: oItem.product,
                                uniqueIDDescription: oItem.uniqueIDDescription,
                                externalIdentification: oItem.externalIdentification,
                                validFrom: oItem.validFrom,
                                validTo: oItem.validTo,
                                characteristic: "",
                                characteristicValue: ""
                            });
                        }
                    });
        
                    // **Sort data by Product, Unique ID, Valid From, and Characteristic**
                    aFlattenedData.sort((a, b) => 
                        a.product.localeCompare(b.product) || 
                        a.uniqueIDDescription.localeCompare(b.uniqueIDDescription) ||
                        a.validFrom.localeCompare(b.validFrom) ||
                        a.characteristic.localeCompare(b.characteristic)
                    );
        
                    if (!that._oLogDialog) {
                        that._oLogDialog = sap.ui.xmlfragment("com.cpidslogs.fragments.reqLogFragmnet", that);
                        that.getView().addDependent(that._oLogDialog);
                    }
        
                    var oLogModel = new sap.ui.model.json.JSONModel({ vcRulesList: aFlattenedData });
                    that._oLogDialog.setModel(oLogModel);
                    that._oLogDialog.open();
                },
                error: function(oError) {
                    console.error("Error fetching data:", oError);
                }
            };
        
            oModel.callFunction("/getRequestLogs", oParameters);
        },
        
        onClose: function() {
            // Close the dialog when "Close" button is pressed
            this._oLogDialog.close();
        },
        







        // ----valuehelp-----
        // onViewLogPress: function () {
        //     if (!this._oProductFragment) {
        //         this._oProductFragment = Fragment.load({
        //             id: 'reqLogFragmnet',
        //             name: "com.cpidslogs.fragments.reqLogFragmnet",
        //             controller: this
        //         }).then(function (oDialog) {
        //             this.getView().addDependent(oDialog);
        //             return oDialog;
        //         }.bind(this));
        //     }
        //     this._oProductFragment.then(function (oDialog) {
        //         oDialog.open();
        //     });
        // },
      



       







    });
});